//
//  KakaoAdSDK.h
//  KakaoAdSDK
//
//  Created by KAKAO on 2017. 12. 12..
//  Copyright © 2017년 KAKAO. All rights reserved.
//

#import <UIKit/UIKit.h>

FOUNDATION_EXPORT double KakaoAdSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char KakaoAdSDKVersionString[];



